CREATE TABLE IF NOT EXISTS bm_users (
  id UUID PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(254) NOT NULL,
  password_hash VARCHAR(100) NOT NULL,
  phone VARCHAR(24) NOT NULL,
  city VARCHAR(100) NOT NULL,
  state_code CHAR(2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT bm_users_state_code_format CHECK (state_code ~ '^[A-Z]{2}$')
);

CREATE UNIQUE INDEX IF NOT EXISTS bm_users_email_lower_unique ON bm_users (LOWER(email));

-- Public seller profile fields are separate from private account contact details.
ALTER TABLE bm_users ADD COLUMN IF NOT EXISTS seller_bio VARCHAR(700);
ALTER TABLE bm_users ADD COLUMN IF NOT EXISTS whatsapp_phone VARCHAR(24);
ALTER TABLE bm_users ADD COLUMN IF NOT EXISTS instagram_url VARCHAR(500);
ALTER TABLE bm_users ADD COLUMN IF NOT EXISTS facebook_url VARCHAR(500);
ALTER TABLE bm_users ADD COLUMN IF NOT EXISTS tiktok_url VARCHAR(500);
ALTER TABLE bm_users ADD COLUMN IF NOT EXISTS youtube_url VARCHAR(500);
ALTER TABLE bm_users ADD COLUMN IF NOT EXISTS x_url VARCHAR(500);
ALTER TABLE bm_users ADD COLUMN IF NOT EXISTS linkedin_url VARCHAR(500);
ALTER TABLE bm_users ADD COLUMN IF NOT EXISTS other_social_url VARCHAR(2000);
ALTER TABLE bm_users ALTER COLUMN other_social_url TYPE VARCHAR(2000);
ALTER TABLE bm_users ADD COLUMN IF NOT EXISTS website_url VARCHAR(500);
ALTER TABLE bm_users ADD COLUMN IF NOT EXISTS public_profile_consent_at TIMESTAMPTZ;

CREATE TABLE IF NOT EXISTS toy_listings (
  id UUID PRIMARY KEY,
  seller_id UUID NOT NULL REFERENCES bm_users(id) ON DELETE RESTRICT,
  title VARCHAR(100) NOT NULL,
  category VARCHAR(20) NOT NULL,
  decade SMALLINT,
  item_condition VARCHAR(30) NOT NULL,
  price NUMERIC(12, 2) NOT NULL CHECK (price > 0),
  description VARCHAR(1200) NOT NULL,
  image_url VARCHAR(500),
  status VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT toy_listings_category_allowed CHECK (category IN ('CARRINHOS', 'BONECAS', 'JOGOS', 'OUTROS')),
  CONSTRAINT toy_listings_condition_allowed CHECK (item_condition IN ('EXCELENTE', 'MUITO_BOA', 'BOA', 'COM_MARCAS_DO_TEMPO')),
  CONSTRAINT toy_listings_status_allowed CHECK (status IN ('AVAILABLE', 'RESERVED', 'SOLD'))
);

CREATE INDEX IF NOT EXISTS toy_listings_status_created_idx ON toy_listings (status, created_at DESC);
CREATE INDEX IF NOT EXISTS toy_listings_seller_idx ON toy_listings (seller_id, created_at DESC);
