package br.com.boasmemorias.product;

public enum ItemCondition {
    EXCELENTE, MUITO_BOA, BOA, COM_MARCAS_DO_TEMPO
}
