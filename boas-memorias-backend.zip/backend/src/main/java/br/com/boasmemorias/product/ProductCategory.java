package br.com.boasmemorias.product;

public enum ProductCategory {
    CARRINHOS, BONECAS, JOGOS, OUTROS
}
