package br.com.boasmemorias.product;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

import br.com.boasmemorias.user.StoreUser;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

@Entity
@Table(name = "toy_listings")
public class ToyListing {
    @Id
    @GeneratedValue
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "seller_id", nullable = false)
    private StoreUser seller;

    @Column(nullable = false, length = 100)
    private String title;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ProductCategory category;

    @Column
    private Short decade;

    @Enumerated(EnumType.STRING)
    @Column(name = "item_condition", nullable = false, length = 30)
    private ItemCondition condition;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal price;

    @Column(nullable = false, length = 1200)
    private String description;

    @Column(name = "image_url", length = 500)
    private String imageUrl;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ListingStatus status;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected ToyListing() {}

    public ToyListing(StoreUser seller, String title, ProductCategory category, Short decade,
            ItemCondition condition, BigDecimal price, String description, String imageUrl) {
        this.seller = seller;
        this.title = title;
        this.category = category;
        this.decade = decade;
        this.condition = condition;
        this.price = price;
        this.description = description;
        this.imageUrl = imageUrl;
        this.status = ListingStatus.AVAILABLE;
    }

    @PrePersist
    void prePersist() {
        if (createdAt == null) createdAt = Instant.now();
        if (status == null) status = ListingStatus.AVAILABLE;
    }

    public UUID getId() { return id; }
    public StoreUser getSeller() { return seller; }
    public String getTitle() { return title; }
    public ProductCategory getCategory() { return category; }
    public Short getDecade() { return decade; }
    public ItemCondition getCondition() { return condition; }
    public BigDecimal getPrice() { return price; }
    public String getDescription() { return description; }
    public String getImageUrl() { return imageUrl; }
    public ListingStatus getStatus() { return status; }
    public Instant getCreatedAt() { return createdAt; }
}
