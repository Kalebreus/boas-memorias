package br.com.boasmemorias.product;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ToyListingRepository extends JpaRepository<ToyListing, UUID> {
    @EntityGraph(attributePaths = "seller")
    List<ToyListing> findAllByStatusOrderByCreatedAtDesc(ListingStatus status);

    @EntityGraph(attributePaths = "seller")
    List<ToyListing> findAllBySeller_IdAndStatusOrderByCreatedAtDesc(UUID sellerId, ListingStatus status);
}
