package br.com.boasmemorias.product;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import br.com.boasmemorias.user.StoreUser;
import br.com.boasmemorias.user.StoreUserRepository;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    private final ToyListingRepository listings;
    private final StoreUserRepository users;

    public ProductController(ToyListingRepository listings, StoreUserRepository users) {
        this.listings = listings;
        this.users = users;
    }

    @GetMapping
    public List<ProductResponse> listAvailable() {
        return listings.findAllByStatusOrderByCreatedAtDesc(ListingStatus.AVAILABLE)
                .stream()
                .filter(listing -> listing.getSeller().hasCompletePublicProfile())
                .map(ProductResponse::from).toList();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CreatedResponse create(@Valid @RequestBody ProductRequest request, Authentication authentication) {
        String email = authentication.getName();
        StoreUser seller = users.findByEmailIgnoreCase(email)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Entre novamente na sua conta."));
        if (!seller.hasCompletePublicProfile()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Complete e salve seu perfil público antes de publicar um anúncio.");
        }
        ToyListing saved = listings.save(new ToyListing(seller, request.title().strip(), request.category(),
                request.decade(), request.condition(), request.price(), request.description().strip(), request.imageUrl()));
        return new CreatedResponse(ProductResponse.from(saved));
    }

    public record ProductRequest(
            @NotBlank @Size(min = 2, max = 100) String title,
            @NotNull ProductCategory category,
            @Min(1940) @Max(2030) Short decade,
            @NotNull ItemCondition condition,
            @NotNull @DecimalMin("1.00") @DecimalMax("1000000.00") BigDecimal price,
            @NotBlank @Size(min = 20, max = 1200) String description,
            @Size(max = 500) @Pattern(regexp = "^$|^https://[^\\s]+$", message = "A foto precisa usar um link público HTTPS.") String imageUrl) {}

    public record CreatedResponse(ProductResponse product) {}

    public record ProductResponse(
            UUID id, String title, ProductCategory category, Short decade,
            ItemCondition condition, BigDecimal price, String description, String imageUrl, String status,
            SellerSummary seller) {
        static ProductResponse from(ToyListing listing) {
            return new ProductResponse(listing.getId(), listing.getTitle(), listing.getCategory(), listing.getDecade(),
                    listing.getCondition(), listing.getPrice(), listing.getDescription(), listing.getImageUrl(),
                    listing.getStatus().name(), SellerSummary.from(listing.getSeller()));
        }
    }

    public record SellerSummary(UUID id, String name, String city, String state,
            BigDecimal ratingAverage, int ratingCount) {
        static SellerSummary from(StoreUser seller) {
            // Ratings stay empty until completed sales can be verified by the platform.
            return new SellerSummary(seller.getId(), seller.getFullName(), seller.getCity(),
                    seller.getStateCode(), null, 0);
        }
    }
}
