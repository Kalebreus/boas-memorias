package br.com.boasmemorias.api;

import java.util.Map;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

@RestControllerAdvice
public class ApiExceptionHandler {
    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<ApiError> invalidRequest(MethodArgumentNotValidException exception) {
        String detail = exception.getBindingResult().getFieldErrors().stream()
                .map(FieldError::getDefaultMessage).filter(message -> message != null && !message.isBlank())
                .findFirst().orElse("Revise os campos e tente novamente.");
        return ResponseEntity.badRequest().body(new ApiError("Dados inválidos.", detail));
    }

    @ExceptionHandler(ResponseStatusException.class)
    ResponseEntity<ApiError> knownError(ResponseStatusException exception) {
        HttpStatus status = HttpStatus.valueOf(exception.getStatusCode().value());
        String message = exception.getReason() == null ? "Não foi possível concluir a solicitação." : exception.getReason();
        return ResponseEntity.status(status).body(new ApiError(message, message));
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    ResponseEntity<ApiError> duplicateOrInvalidData(DataIntegrityViolationException exception) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(new ApiError("Não foi possível salvar estes dados.", "Verifique se o e-mail ou a informação já existe."));
    }

    @ExceptionHandler(Exception.class)
    ResponseEntity<ApiError> unexpected(Exception exception) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ApiError("Ocorreu um erro inesperado.", "Tente novamente em alguns instantes."));
    }

    public record ApiError(String message, String detail) {}
}
