package br.com.boasmemorias.product;

public enum ListingStatus {
    AVAILABLE, RESERVED, SOLD
}
