package br.com.boasmemorias.user;

import java.net.URI;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import jakarta.validation.Valid;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import br.com.boasmemorias.product.ListingStatus;
import br.com.boasmemorias.product.ProductCategory;
import br.com.boasmemorias.product.ItemCondition;
import br.com.boasmemorias.product.ToyListing;
import br.com.boasmemorias.product.ToyListingRepository;

@RestController
@RequestMapping("/api/sellers")
public class SellerProfileController {
    private final StoreUserRepository users;
    private final ToyListingRepository listings;

    public SellerProfileController(StoreUserRepository users, ToyListingRepository listings) {
        this.users = users;
        this.listings = listings;
    }

    @GetMapping("/me")
    public OwnProfileResponse myProfile(Authentication authentication) {
        StoreUser seller = currentUser(authentication);
        return OwnProfileResponse.from(seller);
    }

    @PutMapping("/me/profile")
    public OwnProfileResponse updateMyProfile(@Valid @RequestBody ProfileRequest request,
            Authentication authentication) {
        if (!request.hasSocialLink()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Informe pelo menos um perfil social público.");
        }
        StoreUser seller = currentUser(authentication);
        seller.updatePublicProfile(request.bio().strip(), request.whatsapp().strip(),
                validateOptionalUrl(request.instagramUrl()), validateOptionalUrl(request.facebookUrl()),
                validateOptionalUrl(request.tiktokUrl()), validateOptionalUrl(request.youtubeUrl()),
                validateOptionalUrl(request.xUrl()), validateOptionalUrl(request.linkedinUrl()),
                cleanSocialList(request.otherSocialUrls()), validateOptionalUrl(request.websiteUrl()));
        return OwnProfileResponse.from(users.save(seller));
    }

    @GetMapping("/{id}")
    public PublicProfileResponse publicProfile(@PathVariable UUID id) {
        StoreUser seller = users.findById(id)
                .filter(StoreUser::hasCompletePublicProfile)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Este perfil público ainda não está disponível."));
        List<PublicListing> publicListings = listings
                .findAllBySeller_IdAndStatusOrderByCreatedAtDesc(id, ListingStatus.AVAILABLE)
                .stream().map(PublicListing::from).toList();
        return PublicProfileResponse.from(seller, publicListings);
    }

    private StoreUser currentUser(Authentication authentication) {
        if (authentication == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Entre novamente na sua conta.");
        }
        return users.findByEmailIgnoreCase(authentication.getName())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED,
                        "Entre novamente na sua conta."));
    }

    private static String cleanOptional(String value) {
        if (value == null || value.isBlank()) return null;
        String normalized = value.strip();
        try {
            URI uri = URI.create(normalized);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null) return null;
            return uri.toASCIIString();
        } catch (IllegalArgumentException exception) {
            return null;
        }
    }

    private static String validateOptionalUrl(String value) {
        if (value == null || value.isBlank()) return null;
        String normalized = cleanOptional(value);
        if (normalized == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Cada link público precisa usar HTTPS e ter um endereço válido.");
        }
        return normalized;
    }

    private static String cleanSocialList(String value) {
        if (value == null || value.isBlank()) return null;
        List<String> urls = value.lines()
                .map(String::strip)
                .filter(url -> !url.isBlank())
                .map(SellerProfileController::validateOptionalUrl)
                .toList();
        return urls.isEmpty() ? null : String.join("\n", urls);
    }

    public record ProfileRequest(
            @NotBlank @Size(min = 30, max = 700) String bio,
            @NotBlank @Pattern(regexp = "^[+0-9() .-]{10,24}$") String whatsapp,
            @Size(max = 500) @Pattern(regexp = "^$|^https://[^\\s]+$", message = "Use um link HTTPS válido.") String instagramUrl,
            @Size(max = 500) @Pattern(regexp = "^$|^https://[^\\s]+$", message = "Use um link HTTPS válido.") String facebookUrl,
            @Size(max = 500) @Pattern(regexp = "^$|^https://[^\\s]+$", message = "Use um link HTTPS válido.") String tiktokUrl,
            @Size(max = 500) @Pattern(regexp = "^$|^https://[^\\s]+$", message = "Use um link HTTPS válido.") String youtubeUrl,
            @Size(max = 500) @Pattern(regexp = "^$|^https://[^\\s]+$", message = "Use um link HTTPS válido.") String xUrl,
            @Size(max = 500) @Pattern(regexp = "^$|^https://[^\\s]+$", message = "Use um link HTTPS válido.") String linkedinUrl,
            @Size(max = 2000) String otherSocialUrls,
            @Size(max = 500) @Pattern(regexp = "^$|^https://[^\\s]+$", message = "Use um link HTTPS válido.") String websiteUrl,
            @AssertTrue(message = "Autorize a exibição pública do seu nome, cidade, resumo e contatos informados.")
            boolean publicContactConsent) {
        boolean hasSocialLink() {
            return hasText(instagramUrl) || hasText(facebookUrl)
                    || hasText(tiktokUrl) || hasText(youtubeUrl) || hasText(xUrl)
                    || hasText(linkedinUrl) || hasText(otherSocialUrls);
        }

        private static boolean hasText(String value) {
            return value != null && !value.isBlank();
        }
    }

    public record OwnProfileResponse(boolean complete, String bio, String whatsapp,
            String instagramUrl, String facebookUrl, String tiktokUrl, String youtubeUrl,
            String xUrl, String linkedinUrl, String otherSocialUrls, String websiteUrl) {
        static OwnProfileResponse from(StoreUser seller) {
            return new OwnProfileResponse(seller.hasCompletePublicProfile(), seller.getSellerBio(),
                    seller.getWhatsappPhone(), seller.getInstagramUrl(), seller.getFacebookUrl(),
                    seller.getTiktokUrl(), seller.getYoutubeUrl(), seller.getXUrl(),
                    seller.getLinkedinUrl(), seller.getOtherSocialUrls(), seller.getWebsiteUrl());
        }
    }

    public record SocialLink(String network, String url) {}

    public record PublicListing(UUID id, String title, ProductCategory category, Short decade,
            ItemCondition condition, java.math.BigDecimal price, String imageUrl, Instant createdAt) {
        static PublicListing from(ToyListing listing) {
            return new PublicListing(listing.getId(), listing.getTitle(), listing.getCategory(),
                    listing.getDecade(), listing.getCondition(), listing.getPrice(),
                    listing.getImageUrl(), listing.getCreatedAt());
        }
    }

    public record PublicProfileResponse(UUID id, String name, String city, String state, String bio,
            String whatsapp, List<SocialLink> socialLinks, java.math.BigDecimal ratingAverage,
            int ratingCount, Instant memberSince, List<PublicListing> listings) {
        static PublicProfileResponse from(StoreUser seller, List<PublicListing> listings) {
            List<SocialLink> links = new ArrayList<>();
            addLink(links, "Instagram", seller.getInstagramUrl());
            addLink(links, "Facebook", seller.getFacebookUrl());
            addLink(links, "TikTok", seller.getTiktokUrl());
            addLink(links, "YouTube", seller.getYoutubeUrl());
            addLink(links, "X", seller.getXUrl());
            addLink(links, "LinkedIn", seller.getLinkedinUrl());
            if (seller.getOtherSocialUrls() != null) {
                int number = 1;
                for (String url : seller.getOtherSocialUrls().lines().toList()) {
                    addLink(links, "Outra rede social " + number++, url);
                }
            }
            addLink(links, "Site", seller.getWebsiteUrl());
            // No score is fabricated; a verified order and review workflow is not configured yet.
            return new PublicProfileResponse(seller.getId(), seller.getFullName(), seller.getCity(),
                    seller.getStateCode().toUpperCase(Locale.ROOT), seller.getSellerBio(),
                    seller.getWhatsappPhone(), List.copyOf(links), null, 0,
                    seller.getCreatedAt(), listings);
        }

        private static void addLink(List<SocialLink> links, String network, String url) {
            if (url != null && !url.isBlank()) links.add(new SocialLink(network, url));
        }
    }
}
