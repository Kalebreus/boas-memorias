package br.com.boasmemorias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoasMemoriasApplication {
    public static void main(String[] args) {
        SpringApplication.run(BoasMemoriasApplication.class, args);
    }
}
