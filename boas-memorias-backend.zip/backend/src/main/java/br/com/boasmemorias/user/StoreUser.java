package br.com.boasmemorias.user;

import java.time.Instant;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

@Entity
@Table(name = "bm_users")
public class StoreUser {
    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "full_name", nullable = false, length = 100)
    private String fullName;

    @Column(nullable = false, length = 254)
    private String email;

    @Column(name = "password_hash", nullable = false, length = 100)
    private String passwordHash;

    @Column(nullable = false, length = 24)
    private String phone;

    @Column(nullable = false, length = 100)
    private String city;

    @Column(name = "state_code", nullable = false, length = 2)
    private String stateCode;

    @Column(name = "seller_bio", length = 700)
    private String sellerBio;

    @Column(name = "whatsapp_phone", length = 24)
    private String whatsappPhone;

    @Column(name = "instagram_url", length = 500)
    private String instagramUrl;

    @Column(name = "facebook_url", length = 500)
    private String facebookUrl;

    @Column(name = "tiktok_url", length = 500)
    private String tiktokUrl;

    @Column(name = "youtube_url", length = 500)
    private String youtubeUrl;

    @Column(name = "x_url", length = 500)
    private String xUrl;

    @Column(name = "linkedin_url", length = 500)
    private String linkedinUrl;

    @Column(name = "other_social_url", length = 2000)
    private String otherSocialUrls;

    @Column(name = "website_url", length = 500)
    private String websiteUrl;

    @Column(name = "public_profile_consent_at")
    private Instant publicProfileConsentAt;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    protected StoreUser() {}

    public StoreUser(String fullName, String email, String passwordHash, String phone, String city, String stateCode) {
        this.fullName = fullName;
        this.email = email;
        this.passwordHash = passwordHash;
        this.phone = phone;
        this.city = city;
        this.stateCode = stateCode;
    }

    @PrePersist
    void prePersist() {
        if (createdAt == null) createdAt = Instant.now();
    }

    public UUID getId() { return id; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public String getPasswordHash() { return passwordHash; }
    public String getPhone() { return phone; }
    public String getCity() { return city; }
    public String getStateCode() { return stateCode; }
    public Instant getCreatedAt() { return createdAt; }
    public String getSellerBio() { return sellerBio; }
    public String getWhatsappPhone() { return whatsappPhone; }
    public String getInstagramUrl() { return instagramUrl; }
    public String getFacebookUrl() { return facebookUrl; }
    public String getTiktokUrl() { return tiktokUrl; }
    public String getYoutubeUrl() { return youtubeUrl; }
    public String getXUrl() { return xUrl; }
    public String getLinkedinUrl() { return linkedinUrl; }
    public String getOtherSocialUrls() { return otherSocialUrls; }
    public String getWebsiteUrl() { return websiteUrl; }
    public Instant getPublicProfileConsentAt() { return publicProfileConsentAt; }

    public boolean hasCompletePublicProfile() {
        boolean hasSocialLink = hasText(instagramUrl) || hasText(facebookUrl)
                || hasText(tiktokUrl) || hasText(youtubeUrl) || hasText(xUrl)
                || hasText(linkedinUrl) || hasText(otherSocialUrls);
        return publicProfileConsentAt != null && hasText(sellerBio)
                && hasText(whatsappPhone) && hasSocialLink;
    }

    public void updatePublicProfile(String sellerBio, String whatsappPhone, String instagramUrl,
            String facebookUrl, String tiktokUrl, String youtubeUrl, String xUrl,
            String linkedinUrl, String otherSocialUrls, String websiteUrl) {
        this.sellerBio = sellerBio;
        this.whatsappPhone = whatsappPhone;
        this.instagramUrl = instagramUrl;
        this.facebookUrl = facebookUrl;
        this.tiktokUrl = tiktokUrl;
        this.youtubeUrl = youtubeUrl;
        this.xUrl = xUrl;
        this.linkedinUrl = linkedinUrl;
        this.otherSocialUrls = otherSocialUrls;
        this.websiteUrl = websiteUrl;
        this.publicProfileConsentAt = Instant.now();
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}
