package br.com.boasmemorias.security;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {
    private final SecretKey signingKey;
    private final long ttlMinutes;

    public JwtService(
            @Value("${app.jwt.secret-base64}") String secretBase64,
            @Value("${app.jwt.ttl-minutes:120}") long ttlMinutes) {
        if (secretBase64 == null || secretBase64.isBlank()) {
            throw new IllegalStateException("Defina JWT_SECRET_BASE64 com uma chave aleatória segura de pelo menos 32 bytes.");
        }
        try {
            this.signingKey = Keys.hmacShaKeyFor(Decoders.BASE64.decode(secretBase64));
        } catch (RuntimeException exception) {
            throw new IllegalStateException("JWT_SECRET_BASE64 precisa conter uma chave Base64 válida de pelo menos 32 bytes.", exception);
        }
        if (ttlMinutes < 5 || ttlMinutes > 1440) {
            throw new IllegalStateException("JWT_TTL_MINUTES deve estar entre 5 e 1440 minutos.");
        }
        this.ttlMinutes = ttlMinutes;
    }

    public String issue(String email) {
        Instant issuedAt = Instant.now();
        return Jwts.builder()
                .subject(email)
                .issuedAt(Date.from(issuedAt))
                .expiration(Date.from(issuedAt.plus(ttlMinutes, ChronoUnit.MINUTES)))
                .signWith(signingKey)
                .compact();
    }

    public String subject(String token) throws JwtException {
        Claims claims = Jwts.parser()
                .verifyWith(signingKey)
                .build()
                .parseSignedClaims(token)
                .getPayload();
        return claims.getSubject();
    }
}
