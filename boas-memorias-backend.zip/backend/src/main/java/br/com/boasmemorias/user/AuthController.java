package br.com.boasmemorias.user;

import java.nio.charset.StandardCharsets;
import java.util.Locale;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import br.com.boasmemorias.security.JwtService;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final StoreUserRepository users;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthController(StoreUserRepository users, PasswordEncoder passwordEncoder, JwtService jwtService) {
        this.users = users;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public AuthResponse register(@Valid @RequestBody RegisterRequest request) {
        validateBcryptLength(request.password());
        String email = request.email().strip().toLowerCase(Locale.ROOT);
        if (users.existsByEmailIgnoreCase(email)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Este e-mail já está cadastrado.");
        }

        StoreUser saved = users.save(new StoreUser(
                request.name().strip(), email, passwordEncoder.encode(request.password()),
                request.phone().strip(), request.city().strip(), request.state().toUpperCase(Locale.ROOT)));
        return authResponse(saved);
    }

    @PostMapping("/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest request) {
        String email = request.email().strip().toLowerCase(Locale.ROOT);
        if (request.password().getBytes(StandardCharsets.UTF_8).length > 72) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "E-mail ou senha não conferem.");
        }
        StoreUser user = users.findByEmailIgnoreCase(email)
                .filter(found -> passwordEncoder.matches(request.password(), found.getPasswordHash()))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "E-mail ou senha não conferem."));
        return authResponse(user);
    }

    private AuthResponse authResponse(StoreUser user) {
        return new AuthResponse(jwtService.issue(user.getEmail()), new UserSummary(
                user.getId(), user.getFullName(), user.getEmail(), user.getCity(), user.getStateCode()));
    }

    private void validateBcryptLength(String password) {
        if (password.getBytes(StandardCharsets.UTF_8).length > 72) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "A senha deve ocupar até 72 bytes em UTF-8.");
        }
    }

    public record RegisterRequest(
            @NotBlank @Size(min = 2, max = 100) String name,
            @NotBlank @Email @Size(max = 254) String email,
            @NotBlank @Pattern(regexp = "^[+0-9() .-]{10,24}$") String phone,
            @NotBlank @Size(max = 100) String city,
            @NotBlank @Pattern(regexp = "^[A-Za-z]{2}$") String state,
            @NotBlank @Size(min = 10, max = 72) String password) {}

    public record LoginRequest(
            @NotBlank @Email @Size(max = 254) String email,
            @NotBlank @Size(max = 72) String password) {}

    public record UserSummary(java.util.UUID id, String name, String email, String city, String state) {}
    public record AuthResponse(String accessToken, UserSummary user) {}
}
