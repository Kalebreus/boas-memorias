package br.com.boasmemorias.product;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ToyListingRepository extends JpaRepository<ToyListing, UUID> {
    List<ToyListing> findAllByStatusOrderByCreatedAtDesc(ListingStatus status);
}
